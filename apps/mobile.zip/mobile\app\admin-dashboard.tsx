import React, { useMemo, useState } from "react";
import {
  Alert,
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
  useWindowDimensions,
  View,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { useRouter } from "expo-router";
import Svg, { Circle, Path, Rect } from "react-native-svg";
import { ClinicQLogo } from "../components/ui/ClinicQLogo";
import { Colors } from "../constants/colors";
import { useAuthStore } from "../stores/authStore";

type AdminSection = "staff" | "analytics" | "medications" | "scanner";

const sections: Array<{ id: AdminSection; label: string }> = [
  { id: "staff", label: "Staff" },
  { id: "analytics", label: "Analytics" },
  { id: "medications", label: "Medication Stock" },
  { id: "scanner", label: "Scanner" },
];

const staff = [
  ["Thandi Mokoena", "Professional Nurse", "General Consultation", "On Duty"],
  ["Nomsa Dlamini", "Enrolled Nurse", "Chronic Care", "On Duty"],
  ["Lerato Jacobs", "Professional Nurse", "Immunization", "On Duty"],
  ["Sipho Khumalo", "Enrolled Nurse", "Minor Treatment", "Break"],
  ["Zanele Ngcobo", "Professional Nurse", "Maternal & Child Health", "On Duty"],
];

const stock = [
  ["Paracetamol 500mg", "1,250 tabs", "In Stock", "45 days"],
  ["Amoxicillin 250mg", "120 caps", "Low Stock", "3 days"],
  ["Salbutamol Inhaler", "0 inhalers", "Out of Stock", "0 days"],
  ["Metformin 500mg", "230 tabs", "Low Stock", "5 days"],
  ["Amlodipine 5mg", "560 tabs", "In Stock", "25 days"],
];

function BackIcon() {
  return (
    <Svg width={22} height={22} viewBox="0 0 24 24" fill="none">
      <Path d="M19 12H5M12 19L5 12L12 5" stroke={Colors.dark} strokeWidth={2.2} strokeLinecap="round" strokeLinejoin="round" />
    </Svg>
  );
}

function BellIcon() {
  return (
    <View>
      <Svg width={22} height={22} viewBox="0 0 24 24" fill="none">
        <Path d="M18 16V11C18 7.7 15.3 5 12 5S6 7.7 6 11V16L4 18H20L18 16Z" stroke={Colors.dark} strokeWidth={2} />
        <Path d="M10 21H14" stroke={Colors.dark} strokeWidth={2} strokeLinecap="round" />
      </Svg>
      <View style={styles.notificationDot}>
        <Text style={styles.notificationText}>6</Text>
      </View>
    </View>
  );
}

function StatCard({ title, value, note, tone = Colors.primary }: { title: string; value: string; note: string; tone?: string }) {
  return (
    <View style={[styles.statCard, { borderColor: tone + "30", backgroundColor: tone + "08" }]}>
      <Text style={[styles.statTitle, { color: tone }]}>{title}</Text>
      <Text style={styles.statValue}>{value}</Text>
      <Text style={styles.statNote}>{note}</Text>
    </View>
  );
}

function Pill({ label }: { label: string }) {
  const color = label.includes("Out") ? Colors.danger : label.includes("Low") || label === "Break" ? Colors.secondary : Colors.primary;
  return (
    <View style={[styles.pill, { backgroundColor: color + "16" }]}>
      <Text style={[styles.pillText, { color }]}>{label}</Text>
    </View>
  );
}

export default function ExpoAdminDashboard() {
  const router = useRouter();
  const { width } = useWindowDimensions();
  const isWide = width >= 820;
  const [active, setActive] = useState<AdminSection>("staff");
  const adminName = useAuthStore((s) => s.adminName);
  const logout = useAuthStore((s) => s.logout);

  const title = useMemo(() => {
    if (active === "analytics") return "Queue Analytics";
    if (active === "medications") return "Medication Stock Dashboard";
    if (active === "scanner") return "Nurse Quick Scanner";
    return "Staff Management";
  }, [active]);

  const subtitle = useMemo(() => {
    if (active === "analytics") return "Monitor and improve patient queue performance";
    if (active === "medications") return "Monitor inventory, detect low stock and manage restocks";
    if (active === "scanner") return "Scan patient QR code to check-in and view queue information instantly.";
    return "Manage staff, assign queues and organize shifts";
  }, [active]);

  const signOut = () => {
    logout();
    router.replace("/auth/phone");
  };

  return (
    <SafeAreaView style={styles.safeArea} edges={["top"]}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.replace("/auth/phone")} style={styles.headerBtn}>
          <BackIcon />
        </TouchableOpacity>
        <ClinicQLogo size={32} />
        <TouchableOpacity onPress={() => Alert.alert("Alerts", "6 admin alerts need review.")} style={styles.headerBtn}>
          <BellIcon />
        </TouchableOpacity>
      </View>

      <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.nav} contentContainerStyle={styles.navContent}>
        {sections.map((section) => (
          <TouchableOpacity
            key={section.id}
            onPress={() => setActive(section.id)}
            style={[styles.navChip, active === section.id ? styles.navChipActive : null]}
          >
            <Text style={[styles.navChipText, active === section.id ? styles.navChipTextActive : null]}>{section.label}</Text>
          </TouchableOpacity>
        ))}
        <TouchableOpacity onPress={signOut} style={styles.navChip}>
          <Text style={styles.navChipText}>Sign Out</Text>
        </TouchableOpacity>
      </ScrollView>

      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.content}>
        <View style={styles.pageHeader}>
          <View>
            <Text style={styles.eyebrow}>ClinicQ Admin {adminName ? `• ${adminName}` : ""}</Text>
            <Text style={styles.title}>{title}</Text>
            <Text style={styles.subtitle}>{subtitle}</Text>
          </View>
          {active === "staff" ? (
            <TouchableOpacity style={styles.primaryButton}>
              <Text style={styles.primaryButtonText}>+ Add Staff</Text>
            </TouchableOpacity>
          ) : null}
        </View>

        {active === "staff" ? <StaffPanel isWide={isWide} /> : null}
        {active === "analytics" ? <AnalyticsPanel isWide={isWide} /> : null}
        {active === "medications" ? <MedicationPanel isWide={isWide} /> : null}
        {active === "scanner" ? <ScannerPanel isWide={isWide} /> : null}
      </ScrollView>
    </SafeAreaView>
  );
}

function StaffPanel({ isWide }: { isWide: boolean }) {
  return (
    <>
      <View style={[styles.statGrid, isWide ? styles.gridFour : null]}>
        <StatCard title="Active Staff" value="28" note="of 32 total staff" />
        <StatCard title="On Duty Now" value="18" note="Across all queues" tone={Colors.blue} />
        <StatCard title="Queues Covered" value="6" note="of 8 total queues" tone={Colors.secondary} />
        <StatCard title="Upcoming Shifts" value="12" note="Next 24 hours" tone={Colors.purple} />
      </View>
      <View style={[styles.sectionGrid, isWide ? styles.gridTwo : null]}>
        <View style={styles.card}>
          <SectionTitle title="Active Nurses" action="View all" />
          {staff.map((item) => (
            <Row key={item[0]} left={item[0]} mid={`${item[1]} • ${item[2]}`} right={<Pill label={item[3]} />} />
          ))}
        </View>
        <View style={styles.card}>
          <SectionTitle title="Queue Assignment" action="View all" />
          {["General Consultation", "Chronic Care", "Immunization", "Maternal & Child Health", "Family Planning"].map((item, index) => (
            <Row key={item} left={item} mid={`${5 - Math.min(index, 3)} staff assigned`} right={<Text style={styles.chevron}>›</Text>} />
          ))}
        </View>
      </View>
      <View style={styles.card}>
        <SectionTitle title="Shift Management" action="Create Shift" />
        {staff.map((item, index) => (
          <Row
            key={`${item[0]}-shift`}
            left={item[0]}
            mid={index % 2 === 0 ? "07:00 - 15:00 Morning Shift" : "15:00 - 23:00 Afternoon Shift"}
            right={<Pill label={item[2]} />}
          />
        ))}
      </View>
    </>
  );
}

function AnalyticsPanel({ isWide }: { isWide: boolean }) {
  return (
    <>
      <View style={[styles.statGrid, isWide ? styles.gridFour : null]}>
        <StatCard title="Average Wait Time" value="42 min" note="↓ 8 min vs last week" />
        <StatCard title="Patients Served" value="1,248" note="↑ 6.4% vs last week" tone={Colors.blue} />
        <StatCard title="Peak Queue Today" value="87 people" note="At 10:00 AM" tone={Colors.purple} />
        <StatCard title="Completion Rate" value="95%" note="↑ 3% vs last week" />
      </View>
      <View style={[styles.sectionGrid, isWide ? styles.gridTwo : null]}>
        <View style={styles.card}>
          <SectionTitle title="Average Wait Time Over Time" />
          <MiniLineChart />
        </View>
        <View style={styles.card}>
          <SectionTitle title="Queue Performance" />
          <Text style={styles.performanceScore}>82</Text>
          <Text style={styles.centerNote}>Good / 100</Text>
          {["Patients left without being seen 5%", "Average service time 12 min", "Patient satisfaction 4.6 / 5"].map((item) => (
            <Row key={item} left={item} mid="Improved" />
          ))}
        </View>
      </View>
    </>
  );
}

function MedicationPanel({ isWide }: { isWide: boolean }) {
  return (
    <>
      <View style={[styles.statGrid, isWide ? styles.gridFour : null]}>
        <StatCard title="Low Stock Items" value="12" note="12% of total items" tone={Colors.danger} />
        <StatCard title="Out of Stock Items" value="4" note="4% of total items" tone={Colors.secondary} />
        <StatCard title="Total Items" value="125" note="Across all categories" />
        <StatCard title="Inventory Value" value="R 285,430" note="Total current value" tone={Colors.blue} />
      </View>
      <View style={styles.card}>
        <SectionTitle title="Current Stock Overview" action="Filter" />
        {stock.map((item) => (
          <Row key={item[0]} left={item[0]} mid={`${item[1]} • ${item[3]} left`} right={<Pill label={item[2]} />} />
        ))}
      </View>
      <View style={[styles.sectionGrid, isWide ? styles.gridTwo : null]}>
        <View style={styles.card}>
          <SectionTitle title="Predicted Shortages" action="View all" />
          {stock.slice(1, 4).map((item) => (
            <Row key={`${item[0]}-shortage`} left={item[0]} mid="Likely to run out soon" right={<Pill label="Order Now" />} />
          ))}
        </View>
        <View style={styles.card}>
          <SectionTitle title="Recent Restock Alerts" action="View all" />
          {["Amoxicillin 250mg is low on stock", "Salbutamol Inhaler is out of stock", "Ciprofloxacin 500mg is out of stock"].map((item) => (
            <Row key={item} left={item} mid="Langa Community Clinic" right={<Pill label="Create Order" />} />
          ))}
        </View>
      </View>
    </>
  );
}

function ScannerPanel({ isWide }: { isWide: boolean }) {
  return (
    <>
      <View style={[styles.sectionGrid, isWide ? styles.gridTwo : null]}>
        <View style={styles.scannerCard}>
          <Text style={styles.scannerTitle}>Scan Patient QR Code</Text>
          <View style={styles.qrBox}>
            <Svg width={170} height={170} viewBox="0 0 170 170">
              <Rect width={170} height={170} rx={8} fill={Colors.white} />
              {Array.from({ length: 56 }).map((_, index) => (
                <Rect
                  key={index}
                  x={(index * 23) % 150 + 10}
                  y={(index * 37) % 150 + 10}
                  width={index % 3 === 0 ? 16 : 9}
                  height={index % 4 === 0 ? 16 : 9}
                  fill={Colors.dark}
                />
              ))}
            </Svg>
          </View>
          <View style={styles.scanLine} />
          <TouchableOpacity style={styles.flashButton}>
            <Text style={styles.flashButtonText}>Turn on Flash</Text>
          </TouchableOpacity>
        </View>
        <View style={styles.card}>
          <SectionTitle title="How it works" />
          {["Ask the patient for their queue QR code", "Scan the QR code using the camera", "Review patient & queue info", "Tap Check-in to confirm instantly"].map((item, index) => (
            <Row key={item} left={`${index + 1}. ${item}`} mid="" />
          ))}
        </View>
      </View>
      <View style={styles.card}>
        <SectionTitle title="Last Scanned Patient" action="Checked in at 09:21 AM" />
        <Row left="Sipho Khumalo" mid="Queue A023 • 5th in queue • 35-45 min" right={<Pill label="Check-in Patient" />} />
      </View>
    </>
  );
}

function SectionTitle({ title, action }: { title: string; action?: string }) {
  return (
    <View style={styles.sectionTitle}>
      <Text style={styles.sectionHeading}>{title}</Text>
      {action ? <Text style={styles.sectionAction}>{action}</Text> : null}
    </View>
  );
}

function Row({ left, mid, right }: { left: string; mid: string; right?: React.ReactNode }) {
  return (
    <View style={styles.row}>
      <View style={{ flex: 1, minWidth: 0 }}>
        <Text style={styles.rowLeft}>{left}</Text>
        {mid ? <Text style={styles.rowMid}>{mid}</Text> : null}
      </View>
      {right}
    </View>
  );
}

function MiniLineChart() {
  const points = "15,88 66,78 117,86 168,99 219,104 270,112 321,92";
  return (
    <Svg width="100%" height={170} viewBox="0 0 340 170">
      {[35, 70, 105, 140].map((y) => (
        <Path key={y} d={`M0 ${y}H340`} stroke={Colors.border} strokeWidth={1} />
      ))}
      <Path d={`M${points}`} fill="none" stroke={Colors.primary} strokeWidth={4} strokeLinecap="round" strokeLinejoin="round" />
      {points.split(" ").map((point) => {
        const [x, y] = point.split(",").map(Number);
        return <Circle key={point} cx={x} cy={y} r={5} fill={Colors.white} stroke={Colors.primary} strokeWidth={3} />;
      })}
    </Svg>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: Colors.surface,
  },
  header: {
    minHeight: 64,
    paddingHorizontal: 16,
    backgroundColor: Colors.white,
    borderBottomWidth: 1,
    borderBottomColor: Colors.border,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
  headerBtn: {
    width: 42,
    height: 42,
    borderRadius: 21,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: Colors.surface,
  },
  notificationDot: {
    position: "absolute",
    top: -6,
    right: -8,
    minWidth: 18,
    height: 18,
    borderRadius: 9,
    backgroundColor: Colors.danger,
    alignItems: "center",
    justifyContent: "center",
  },
  notificationText: {
    color: Colors.white,
    fontSize: 10,
    fontWeight: "900",
  },
  nav: {
    backgroundColor: Colors.white,
    borderBottomWidth: 1,
    borderBottomColor: Colors.border,
  },
  navContent: {
    paddingHorizontal: 16,
    paddingVertical: 10,
    gap: 8,
  },
  navChip: {
    minHeight: 38,
    paddingHorizontal: 14,
    borderRadius: 19,
    backgroundColor: Colors.surface,
    alignItems: "center",
    justifyContent: "center",
    borderWidth: 1,
    borderColor: Colors.border,
  },
  navChipActive: {
    backgroundColor: Colors.primary,
    borderColor: Colors.primary,
  },
  navChipText: {
    color: Colors.muted,
    fontWeight: "800",
    fontSize: 13,
  },
  navChipTextActive: {
    color: Colors.white,
  },
  content: {
    padding: 18,
    paddingBottom: 40,
    gap: 16,
  },
  pageHeader: {
    gap: 16,
    marginBottom: 4,
  },
  eyebrow: {
    color: Colors.primary,
    fontSize: 12,
    fontWeight: "900",
    textTransform: "uppercase",
  },
  title: {
    color: Colors.dark,
    fontSize: 28,
    fontWeight: "900",
    marginTop: 4,
  },
  subtitle: {
    color: Colors.muted,
    fontSize: 14,
    lineHeight: 20,
    marginTop: 6,
  },
  primaryButton: {
    alignSelf: "flex-start",
    minHeight: 44,
    borderRadius: 10,
    backgroundColor: Colors.primary,
    paddingHorizontal: 18,
    alignItems: "center",
    justifyContent: "center",
  },
  primaryButtonText: {
    color: Colors.white,
    fontWeight: "900",
  },
  statGrid: {
    gap: 12,
  },
  gridFour: {
    flexDirection: "row",
    flexWrap: "wrap",
  },
  gridTwo: {
    flexDirection: "row",
    flexWrap: "wrap",
  },
  sectionGrid: {
    gap: 12,
    marginTop: 12,
  },
  statCard: {
    flex: 1,
    minWidth: 190,
    borderRadius: 14,
    borderWidth: 1,
    padding: 16,
    backgroundColor: Colors.white,
  },
  statTitle: {
    fontSize: 13,
    fontWeight: "900",
  },
  statValue: {
    color: Colors.dark,
    fontSize: 30,
    fontWeight: "900",
    marginTop: 12,
  },
  statNote: {
    color: Colors.muted,
    fontSize: 12,
    marginTop: 4,
  },
  card: {
    flex: 1,
    minWidth: 280,
    backgroundColor: Colors.white,
    borderWidth: 1,
    borderColor: Colors.border,
    borderRadius: 14,
    padding: 16,
    marginTop: 12,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.05,
    shadowRadius: 12,
    elevation: 2,
  },
  sectionTitle: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: 8,
    gap: 10,
  },
  sectionHeading: {
    color: Colors.dark,
    fontSize: 17,
    fontWeight: "900",
  },
  sectionAction: {
    color: Colors.primary,
    fontSize: 12,
    fontWeight: "900",
  },
  row: {
    minHeight: 58,
    flexDirection: "row",
    alignItems: "center",
    gap: 12,
    borderBottomWidth: 1,
    borderBottomColor: Colors.border,
    paddingVertical: 10,
  },
  rowLeft: {
    color: Colors.dark,
    fontSize: 14,
    fontWeight: "800",
  },
  rowMid: {
    color: Colors.muted,
    fontSize: 12,
    marginTop: 3,
  },
  pill: {
    borderRadius: 8,
    minHeight: 28,
    paddingHorizontal: 10,
    alignItems: "center",
    justifyContent: "center",
  },
  pillText: {
    fontSize: 12,
    fontWeight: "900",
  },
  chevron: {
    color: Colors.muted,
    fontSize: 28,
  },
  performanceScore: {
    color: Colors.primary,
    fontSize: 56,
    fontWeight: "900",
    textAlign: "center",
    marginTop: 10,
  },
  centerNote: {
    color: Colors.muted,
    textAlign: "center",
    marginBottom: 12,
    fontWeight: "800",
  },
  scannerCard: {
    minHeight: 360,
    borderRadius: 16,
    backgroundColor: Colors.dark,
    alignItems: "center",
    justifyContent: "center",
    overflow: "hidden",
    padding: 20,
    marginTop: 12,
  },
  scannerTitle: {
    position: "absolute",
    top: 24,
    color: Colors.white,
    fontSize: 16,
    fontWeight: "900",
  },
  qrBox: {
    borderRadius: 12,
    overflow: "hidden",
  },
  scanLine: {
    position: "absolute",
    left: "18%",
    right: "18%",
    top: "50%",
    height: 3,
    backgroundColor: Colors.primaryMid,
  },
  flashButton: {
    position: "absolute",
    bottom: 22,
    minHeight: 40,
    borderRadius: 20,
    paddingHorizontal: 18,
    backgroundColor: "rgba(255,255,255,0.14)",
    alignItems: "center",
    justifyContent: "center",
  },
  flashButtonText: {
    color: Colors.white,
    fontWeight: "900",
  },
});
